from django.apps import AppConfig


class Task1Config(AppConfig):
    name = 'task1'
