from django.apps import AppConfig


class Task2Config(AppConfig):
    name = 'task2'
